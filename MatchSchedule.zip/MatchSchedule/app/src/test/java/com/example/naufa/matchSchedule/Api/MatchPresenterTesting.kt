package com.example.naufa.matchSchedule.Api

import org.junit.Test

import org.junit.Assert.*

class MatchPresenterTesting {

    @Test
    fun getMatchList() {
    }
}