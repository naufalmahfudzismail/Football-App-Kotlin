package com.example.naufa.matchSchedule.Database

import org.junit.Test

import org.junit.Assert.*

class DatabaseHelperTesting {

    @Test
    fun onCreate() {
    }

    @Test
    fun onUpgrade() {
    }
}