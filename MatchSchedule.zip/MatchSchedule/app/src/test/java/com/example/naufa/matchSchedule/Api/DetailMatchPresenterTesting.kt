package com.example.naufa.matchSchedule.Api

import org.junit.Test

import org.junit.Assert.*

class DetailMatchPresenterTesting {

    @Test
    fun getDetailMatch() {
    }
}