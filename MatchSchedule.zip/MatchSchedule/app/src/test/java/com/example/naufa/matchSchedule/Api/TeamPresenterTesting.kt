package com.example.naufa.matchSchedule.Api

import org.junit.Test

import org.junit.Assert.*

class TeamPresenterTesting {

    @Test
    fun geDetailTeamList() {
    }
}