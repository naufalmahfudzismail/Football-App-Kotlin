package com.example.naufa.matchSchedule.Entity

data class TeamResponse(
    val teams: List<Team>
)